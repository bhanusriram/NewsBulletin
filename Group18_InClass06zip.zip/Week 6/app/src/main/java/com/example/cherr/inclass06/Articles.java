package com.example.cherr.inclass06;

/*
InClass_06
Bhanu Teja Sriram
Tejaswini Naredla

*/
public class Articles {
    String title,description,urlToImage,publishedAt;

    public Articles() {
    }
}
